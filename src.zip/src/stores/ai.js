import { defineStore } from 'pinia'
import { nanoid } from './utils'
import { normalizeAiArtifact } from '../domains/ai/aiArtifactRuntime.js'
import {
  buildAiContextBundle,
  normalizeAiSelection,
  recommendAiSkills,
  skillHasRequiredContext,
} from '../domains/ai/aiContextRuntime.js'
import { useEditorStore } from './editor'
import { useFilesStore } from './files'
import { useReferencesStore } from './references'
import { useToastStore } from './toast'
import { t } from '../i18n/index.js'
import {
  AI_BUILT_IN_ACTION_DEFINITIONS,
  buildPreparedAiBrief,
  getAiSkillById,
} from '../services/ai/skillRegistry.js'
import { resolveAiInvocation } from '../services/ai/invocationRouting.js'
import { discoverFilesystemSkills } from '../services/ai/skillDiscovery.js'
import {
  getAiProviderConfig,
  getAiProviderDefinition,
  loadAiApiKey,
  loadAiConfig,
  setCurrentAiProvider,
} from '../services/ai/settings.js'
import { executeAiSkill } from '../services/ai/executor.js'
import { applyAiArtifactCapability } from '../services/ai/artifactCapabilities.js'
import { useWorkspaceStore } from './workspace'

const RECENT_AI_SKILL_IDS_KEY = 'altals.ai.recentSkillIds'

function buildUserMessage(skill = {}, userInstruction = '') {
  const title = String(skill?.titleKey || skill?.id || 'AI task').trim()
  const detail = String(userInstruction || '').trim()
  if (!detail) return title
  return `${title}\n\n${detail}`
}

function normalizeConversation(messages = []) {
  return (Array.isArray(messages) ? messages : [])
    .filter((message) => message && (message.role === 'user' || message.role === 'assistant'))
    .map((message) => ({
      role: message.role,
      content: String(message.content || '').trim(),
    }))
    .filter((message) => message.content)
}

function buildArtifactRecord(skillId = '', artifact = null) {
  if (!artifact) return null
  return {
    id: `artifact:${nanoid()}`,
    skillId,
    status: 'pending',
    createdAt: Date.now(),
    ...artifact,
  }
}

function readRecentSkillIds() {
  try {
    const parsed = JSON.parse(localStorage.getItem(RECENT_AI_SKILL_IDS_KEY) || '[]')
    return Array.isArray(parsed)
      ? parsed.map((item) => String(item || '').trim()).filter(Boolean)
      : []
  } catch {
    return []
  }
}

function writeRecentSkillIds(skillIds = []) {
  try {
    localStorage.setItem(RECENT_AI_SKILL_IDS_KEY, JSON.stringify(skillIds))
  } catch {
    // ignore local storage failures
  }
}

function sortEntriesByRecentUsage(entries = [], recentSkillIds = []) {
  const recentIndex = new Map(recentSkillIds.map((id, index) => [id, index]))
  return [...entries].sort((left, right) => {
    const leftIndex = recentIndex.has(left.id) ? recentIndex.get(left.id) : Number.POSITIVE_INFINITY
    const rightIndex = recentIndex.has(right.id) ? recentIndex.get(right.id) : Number.POSITIVE_INFINITY
    if (leftIndex !== rightIndex) return leftIndex - rightIndex
    return String(left.name || left.titleKey || left.id || '').localeCompare(
      String(right.name || right.titleKey || right.id || '')
    )
  })
}

export const useAiStore = defineStore('ai', {
  state: () => ({
    editorSelection: normalizeAiSelection(),
    activeSkillId: 'grounded-chat',
    promptDraft: '',
    messages: [],
    artifacts: [],
    filesystemSkills: [],
    recentSkillIds: readRecentSkillIds(),
    isRefreshingFilesystemSkills: false,
    lastSkillCatalogError: '',
    lastError: '',
    isRunning: false,
    providerState: {
      ready: false,
      hasKey: false,
      currentProviderId: 'openai',
      currentProviderLabel: 'OpenAI',
      enabledToolIds: [],
      baseUrl: '',
      model: '',
    },
  }),

  getters: {
    currentContextBundle(state) {
      const editorStore = useEditorStore()
      const referencesStore = useReferencesStore()

      return buildAiContextBundle({
        activeFile: editorStore.activeTab,
        selection: state.editorSelection,
        selectedReference: referencesStore.selectedReference,
      })
    },

    builtInActions() {
      return sortEntriesByRecentUsage(
        recommendAiSkills(this.currentContextBundle, AI_BUILT_IN_ACTION_DEFINITIONS),
        this.recentSkillIds
      )
    },

    recommendedSkills() {
      return this.builtInActions
    },

    discoveredFilesystemSkills(state) {
      return sortEntriesByRecentUsage(state.filesystemSkills, state.recentSkillIds)
    },

    activeSkill(state) {
      return (
        getAiSkillById(state.activeSkillId, state.filesystemSkills)
        || state.filesystemSkills[0]
        || this.builtInActions[0]
        || null
      )
    },

    preparedBrief(state) {
      return this.activeSkill
        ? buildPreparedAiBrief(this.activeSkill, this.currentContextBundle, {
          filesystemSkills: state.filesystemSkills,
        })
        : ''
    },

    latestArtifact(state) {
      return state.artifacts[0] || null
    },

    enabledToolIds(state) {
      return Array.isArray(state.providerState.enabledToolIds)
        ? state.providerState.enabledToolIds
        : []
    },
  },

  actions: {
    updateEditorSelection(selection = null) {
      this.editorSelection = normalizeAiSelection(selection)
    },

    clearEditorSelection(filePath = '') {
      if (!filePath || this.editorSelection.filePath === filePath) {
        this.editorSelection = normalizeAiSelection()
      }
    },

    selectSkill(skillId = '') {
      if (!getAiSkillById(skillId, this.filesystemSkills)) return
      this.activeSkillId = skillId
    },

    setPromptDraft(value = '') {
      this.promptDraft = String(value || '')
    },

    clearSession() {
      this.messages = []
      this.artifacts = []
      this.lastError = ''
    },

    recordSkillUsage(skillId = '') {
      const normalized = String(skillId || '').trim()
      if (!normalized) return
      const next = [normalized, ...this.recentSkillIds.filter((id) => id !== normalized)].slice(0, 20)
      this.recentSkillIds = next
      writeRecentSkillIds(next)
    },

    isToolEnabled(toolId = '') {
      return this.enabledToolIds.includes(String(toolId || '').trim())
    },

    async refreshFilesystemSkills() {
      const workspace = useWorkspaceStore()
      this.isRefreshingFilesystemSkills = true
      this.lastSkillCatalogError = ''

      try {
        const skills = await discoverFilesystemSkills({
          workspacePath: workspace.path || '',
          globalConfigDir: workspace.globalConfigDir || '',
        })
        this.filesystemSkills = skills

        if (!getAiSkillById(this.activeSkillId, skills)) {
          this.activeSkillId = skills[0]?.id || 'grounded-chat'
        }
        return skills
      } catch (error) {
        this.lastSkillCatalogError = error instanceof Error
          ? error.message
          : String(error || 'Failed to load filesystem skills.')
        return []
      } finally {
        this.isRefreshingFilesystemSkills = false
      }
    },

    async refreshProviderState() {
      const config = await loadAiConfig()
      const currentProviderId = String(config?.currentProviderId || 'openai').trim()
      const providerConfig = getAiProviderConfig(config, currentProviderId)
      const providerDefinition = getAiProviderDefinition(currentProviderId)
      const apiKey = await loadAiApiKey(currentProviderId)

      this.providerState = {
        ready:
          !!String(providerConfig?.baseUrl || '').trim()
          && !!String(providerConfig?.model || '').trim()
          && !!String(apiKey || '').trim(),
        hasKey: !!String(apiKey || '').trim(),
        currentProviderId,
        currentProviderLabel: providerDefinition?.label || currentProviderId,
        enabledToolIds: Array.isArray(config?.enabledTools) ? config.enabledTools : [],
        baseUrl: String(providerConfig?.baseUrl || '').trim(),
        model: String(providerConfig?.model || '').trim(),
      }
      return this.providerState
    },

    async setCurrentProvider(providerId = '') {
      await setCurrentAiProvider(providerId)
      return this.refreshProviderState()
    },

    async runActiveSkill() {
      const toastStore = useToastStore()
      const invocation = resolveAiInvocation({
        prompt: this.promptDraft,
        activeSkill: this.activeSkill,
        builtInActions: this.builtInActions,
        filesystemSkills: this.filesystemSkills,
      })
      const skill = invocation.resolvedSkill
      if (invocation.resolvedSkill?.id && invocation.resolvedSkill.id !== this.activeSkillId) {
        this.activeSkillId = invocation.resolvedSkill.id
      }
      if (!skill) {
        this.lastError = t('AI skill is not available.')
        return null
      }
      if (skill.kind !== 'filesystem-skill' && !skillHasRequiredContext(skill, this.currentContextBundle)) {
        this.lastError = t('The selected AI skill is missing required context.')
        toastStore.show(this.lastError, { type: 'warning' })
        return null
      }

      const providerState = await this.refreshProviderState()
      if (!providerState.ready) {
        this.lastError = t('AI settings are incomplete. Configure the provider before running a skill.')
        toastStore.show(this.lastError, { type: 'warning' })
        return null
      }

      const fullConfig = await loadAiConfig()
      const providerId = String(fullConfig?.currentProviderId || 'openai').trim()
      const [config, apiKey] = await Promise.all([
        Promise.resolve(getAiProviderConfig(fullConfig, providerId)),
        loadAiApiKey(providerId),
      ])
      const userInstruction = String(invocation.userInstruction || '').trim()
      const priorConversation = normalizeConversation(this.messages.slice(-6))
      const userMessage = {
        id: `message:${nanoid()}`,
        role: 'user',
        content: buildUserMessage(skill, userInstruction),
        createdAt: Date.now(),
      }

      this.messages = [...this.messages, userMessage]
      this.isRunning = true
      this.lastError = ''

      try {
        const result = await executeAiSkill({
          skillId: skill.id,
          skill,
          contextBundle: this.currentContextBundle,
          config: {
            ...config,
            providerId,
          },
          apiKey: apiKey || '',
          userInstruction,
          conversation: priorConversation,
          filesystemSkills: this.filesystemSkills,
        })

        const artifact = buildArtifactRecord(skill.id, normalizeAiArtifact(
          skill.id,
          result.payload,
          this.currentContextBundle,
          result.content
        ))

        const assistantMessage = {
          id: `message:${nanoid()}`,
          role: 'assistant',
          content:
            artifact?.type === 'doc_patch'
              ? artifact.replacementText
              : artifact?.type === 'note_draft'
                ? artifact.content
                : artifact?.content || result.content,
          createdAt: Date.now(),
          artifactId: artifact?.id || '',
        }

        this.messages = [...this.messages, assistantMessage]
        if (artifact) {
          this.artifacts = [artifact, ...this.artifacts]
        }
        this.recordSkillUsage(skill.id)
        this.promptDraft = ''
        return { assistantMessage, artifact }
      } catch (error) {
        this.lastError = error instanceof Error ? error.message : String(error || 'AI execution failed.')
        toastStore.show(this.lastError, { type: 'error' })
        return null
      } finally {
        this.isRunning = false
      }
    },

    async applyArtifact(artifactId = '') {
      const artifact = this.artifacts.find((item) => item.id === artifactId)
      if (!artifact || artifact.status === 'applied') return false

      const toastStore = useToastStore()
      const editorStore = useEditorStore()
      const filesStore = useFilesStore()

      try {
        return await applyAiArtifactCapability(artifact, {
          enabledToolIds: this.enabledToolIds,
          filesStore,
          editorStore,
          toastStore,
          translate: t,
        })
      } catch (error) {
        this.lastError = error instanceof Error ? error.message : String(error || t('Failed to apply AI artifact.'))
        toastStore.show(this.lastError, { type: 'error' })
        return false
      }
    },
  },
})
