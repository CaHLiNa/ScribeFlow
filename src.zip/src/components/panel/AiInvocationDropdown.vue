<template>
  <div v-if="visible && suggestions.length > 0" class="ai-invocation-dropdown">
    <template v-for="(suggestion, index) in suggestions" :key="`${suggestion.prefix}:${suggestion.id}`">
      <div
        v-if="shouldShowGroup(index)"
        class="ai-invocation-dropdown__group"
      >
        {{ suggestion.groupLabel }}
      </div>
      <button
        type="button"
        class="ai-invocation-dropdown__item"
        :class="{ 'is-active': index === activeIndex }"
        @mousedown.prevent="$emit('select', suggestion)"
      >
        <div class="ai-invocation-dropdown__topline">
          <span class="ai-invocation-dropdown__title">{{ suggestion.label }}</span>
          <span class="ai-invocation-dropdown__badge">{{ suggestion.prefix }}</span>
        </div>
        <div v-if="suggestion.description" class="ai-invocation-dropdown__description">
          {{ suggestion.description }}
        </div>
      </button>
    </template>
  </div>
</template>

<script setup>
const props = defineProps({
  visible: { type: Boolean, default: false },
  suggestions: { type: Array, default: () => [] },
  activeIndex: { type: Number, default: 0 },
})

defineEmits(['select'])

function shouldShowGroup(index = 0) {
  if (index <= 0) return true
  const current = props.suggestions[index]?.groupKey || ''
  const previous = props.suggestions[index - 1]?.groupKey || ''
  return current !== previous
}
</script>

<style scoped>
.ai-invocation-dropdown {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: 10px;
  padding: 8px;
  border: 1px solid color-mix(in srgb, var(--border-color) 76%, transparent);
  border-radius: 12px;
  background: color-mix(in srgb, var(--panel-muted) 82%, transparent);
}

.ai-invocation-dropdown__group {
  padding: 4px 8px 0;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: var(--text-secondary);
}

.ai-invocation-dropdown__item {
  display: flex;
  flex-direction: column;
  gap: 4px;
  width: 100%;
  text-align: left;
  padding: 10px;
  border-radius: 10px;
  border: 1px solid transparent;
  background: transparent;
  color: inherit;
}

.ai-invocation-dropdown__item:hover,
.ai-invocation-dropdown__item.is-active {
  border-color: color-mix(in srgb, var(--accent) 34%, var(--border-color) 66%);
  background: color-mix(in srgb, var(--accent) 8%, var(--panel-surface) 92%);
}

.ai-invocation-dropdown__topline {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  align-items: center;
}

.ai-invocation-dropdown__title {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-primary);
}

.ai-invocation-dropdown__badge {
  flex: 0 0 auto;
  padding: 2px 7px;
  border-radius: 999px;
  font-size: 11px;
  color: var(--text-secondary);
  background: color-mix(in srgb, var(--panel-surface) 84%, transparent);
}

.ai-invocation-dropdown__description {
  font-size: 12px;
  line-height: 1.45;
  color: var(--text-secondary);
}
</style>
