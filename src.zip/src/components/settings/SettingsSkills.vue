<template>
  <div class="settings-page">
    <h3 class="settings-section-title">{{ t('Skills') }}</h3>

    <section class="settings-group">
      <h4 class="settings-group-title">{{ t('Skill management') }}</h4>
      <div class="settings-group-body">
        <div class="settings-row">
          <div class="settings-row-copy">
            <div class="settings-row-title">{{ t('Management scope') }}</div>
            <div class="settings-row-hint">
              {{ t('Choose where newly created or imported skills should be managed.') }}
            </div>
          </div>
          <div class="settings-row-control">
            <UiSelect v-model="managementScope" size="sm" :options="scopeOptions" />
          </div>
        </div>

        <div class="settings-row">
          <div class="settings-row-copy">
            <div class="settings-row-title">{{ t('Search skills') }}</div>
            <div class="settings-row-hint">
              {{ t('Filter by skill name, description, source, or support file path.') }}
            </div>
          </div>
          <div class="settings-row-control">
            <UiInput v-model="searchQuery" size="sm" :placeholder="t('Search skills placeholder')" />
          </div>
        </div>

        <div class="settings-row">
          <div class="settings-row-copy">
            <div class="settings-row-title">{{ t('Filesystem skills') }}</div>
            <div class="settings-row-hint">
              {{ t('Manage discovered skills from workspace and user directories, similar to Codex or Goose style skill packs.') }}
            </div>
          </div>
          <div class="settings-row-control compact settings-skills-actions">
            <UiButton variant="secondary" size="sm" @click="createModalVisible = true">
              {{ t('Create skill') }}
            </UiButton>
            <UiButton variant="secondary" size="sm" @click="importSkillFile">
              {{ t('Import SKILL.md') }}
            </UiButton>
            <UiButton variant="secondary" size="sm" @click="importSkillDirectory">
              {{ t('Import skill folder') }}
            </UiButton>
            <UiButton variant="secondary" size="sm" :disabled="aiStore.isRefreshingFilesystemSkills" @click="refreshSkills">
              {{ aiStore.isRefreshingFilesystemSkills ? t('Refreshing...') : t('Refresh skills') }}
            </UiButton>
          </div>
        </div>

        <div v-if="pageError" class="settings-inline-message settings-inline-message-error">
          {{ pageError }}
        </div>
        <div v-else-if="pageSuccess" class="settings-inline-message">
          {{ pageSuccess }}
        </div>
        <div v-if="aiStore.lastSkillCatalogError" class="settings-inline-message settings-inline-message-error">
          {{ aiStore.lastSkillCatalogError }}
        </div>
      </div>
    </section>

    <section class="settings-group">
      <h4 class="settings-group-title">{{ t('Skill groups') }}</h4>
      <div v-if="skillGroups.length === 0" class="settings-inline-message">
        {{ t('No filesystem skills found yet.') }}
      </div>
      <div v-else class="settings-skills-group-list">
        <section
          v-for="group in skillGroups"
          :key="group.id"
          class="settings-skills-group"
        >
          <div class="settings-skills-group__header">
            <h5 class="settings-skills-group__title">{{ group.label }}</h5>
            <div class="settings-skills-group__count">{{ group.skills.length }}</div>
          </div>

          <div class="settings-skills-list">
            <article
              v-for="skill in group.skills"
              :key="skill.id"
              class="settings-skills-card"
            >
              <div class="settings-skills-card__header">
                <div class="settings-skills-card__copy">
                  <div class="settings-skills-card__titleline">
                    <h5 class="settings-skills-card__title">{{ skill.name }}</h5>
                    <span class="settings-skills-card__badge">
                      {{ skill.scope === 'user' ? t('User scope') : t('Workspace scope') }}
                    </span>
                  </div>
                  <p class="settings-skills-card__description">
                    {{ skill.description || t('Filesystem skill with no description.') }}
                  </p>
                </div>
                <div class="settings-skills-card__actions">
                  <UiButton
                    v-if="group.id === 'bundled'"
                    variant="secondary"
                    size="sm"
                    :disabled="managementScope === 'workspace'"
                    @click="installBundled(skill)"
                  >
                    {{ t('Install to selected scope') }}
                  </UiButton>
                  <UiButton variant="secondary" size="sm" @click="openSkillFile(skill)">
                    {{ t('Open skill file') }}
                  </UiButton>
                  <UiButton variant="secondary" size="sm" @click="revealSkillDirectory(skill)">
                    {{ t('Reveal directory') }}
                  </UiButton>
                  <UiButton
                    v-if="canEditSkill(skill)"
                    variant="secondary"
                    size="sm"
                    @click="beginEditSkill(skill)"
                  >
                    {{ t('Edit skill') }}
                  </UiButton>
                  <UiButton
                    v-if="canDuplicateSkill(skill)"
                    variant="secondary"
                    size="sm"
                    @click="duplicateSkill(skill)"
                  >
                    {{ t('Duplicate') }}
                  </UiButton>
                  <UiButton
                    variant="secondary"
                    size="sm"
                    @click="exportSkill(skill)"
                  >
                    {{ t('Export') }}
                  </UiButton>
                  <UiButton
                    v-if="canDeleteSkill(skill)"
                    variant="danger"
                    size="sm"
                    @click="deleteSkill(skill)"
                  >
                    {{ t('Delete') }}
                  </UiButton>
                </div>
              </div>

              <div class="settings-skills-card__meta">
                <div><strong>{{ t('Skill file') }}:</strong> {{ skill.skillFilePath }}</div>
                <div><strong>{{ t('Source root') }}:</strong> {{ skill.sourceRootPath }}</div>
                <div v-if="skill.supportingFiles?.length > 0">
                  <strong>{{ t('Support files') }}:</strong> {{ skill.supportingFiles.join(', ') }}
                </div>
                <div v-if="skill.supportingFiles?.length > 0" class="settings-skills-card__support-actions">
                  <UiButton
                    v-for="supportFile in skill.supportingFiles"
                    :key="`${skill.id}:${supportFile}`"
                    variant="ghost"
                    size="sm"
                    @click="openSupportFile(skill, supportFile)"
                  >
                    {{ supportFile }}
                  </UiButton>
                </div>
              </div>
            </article>
          </div>
        </section>
      </div>
    </section>

    <section class="settings-group">
      <h4 class="settings-group-title">{{ t('Tool registry') }}</h4>
      <div class="settings-group-body">
        <div
          v-for="tool in toolDefinitions"
          :key="tool.id"
          class="settings-row"
        >
          <div class="settings-row-copy">
            <div class="settings-row-title">{{ tool.label }}</div>
            <div class="settings-row-hint">{{ tool.description }}</div>
          </div>
          <div class="settings-row-control">
            <UiSwitch :model-value="enabledToolIds.has(tool.id)" @update:model-value="toggleTool(tool.id, $event)" />
          </div>
        </div>
      </div>
    </section>

    <SkillCreateModal
      :visible="createModalVisible"
      :title="t('Create skill')"
      :submit-label="t('Create skill')"
      :scope="managementScope"
      :name="createSkillForm.name"
      :description="createSkillForm.description"
      :content="createSkillForm.content"
      @close="createModalVisible = false"
      @submit="submitCreateSkill"
      @update:scope="managementScope = $event"
      @update:name="createSkillForm.name = $event"
      @update:description="createSkillForm.description = $event"
      @update:content="createSkillForm.content = $event"
    />

    <SkillCreateModal
      :visible="editModalVisible"
      :title="t('Edit skill')"
      :submit-label="t('Save changes')"
      :scope="editSkillForm.scope"
      disable-scope
      :name="editSkillForm.name"
      :description="editSkillForm.description"
      :content="editSkillForm.content"
      @close="editModalVisible = false"
      @submit="submitEditSkill"
      @update:name="editSkillForm.name = $event"
      @update:description="editSkillForm.description = $event"
      @update:content="editSkillForm.content = $event"
    />
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { ask, open } from '@tauri-apps/plugin-dialog'
import { useI18n } from '../../i18n'
import { useAiStore } from '../../stores/ai'
import { useEditorStore } from '../../stores/editor'
import { useWorkspaceStore } from '../../stores/workspace'
import { revealPathInFileManager } from '../../services/fileTreeSystem.js'
import { AI_TOOL_DEFINITIONS } from '../../services/ai/toolRegistry.js'
import {
  createManagedSkill,
  deleteManagedSkill,
  duplicateWritableSkill,
  exportSkillDirectory,
  importManagedSkill,
  installBundledSkill,
  isManagedSkill,
  isWritableSkill,
  resolveManagedSkillRoots,
  resolveWritableSkillRoots,
  updateManagedSkill,
  updateWritableSkill,
} from '../../services/ai/skillManagement.js'
import { loadAiConfig, saveAiConfig } from '../../services/ai/settings.js'
import SkillCreateModal from './SkillCreateModal.vue'
import UiButton from '../shared/ui/UiButton.vue'
import UiInput from '../shared/ui/UiInput.vue'
import UiSelect from '../shared/ui/UiSelect.vue'
import UiSwitch from '../shared/ui/UiSwitch.vue'

const { t } = useI18n()
const aiStore = useAiStore()
const editorStore = useEditorStore()
const workspace = useWorkspaceStore()

const filesystemSkills = computed(() => aiStore.discoveredFilesystemSkills)
const toolDefinitions = AI_TOOL_DEFINITIONS
const managementScope = ref('workspace')
const searchQuery = ref('')
const enabledToolIds = ref(new Set())
const managedRoots = ref({ workspace: '', user: '' })
const writableRoots = ref([])
const createModalVisible = ref(false)
const editModalVisible = ref(false)
const pageError = ref('')
const pageSuccess = ref('')

const createSkillForm = reactive({
  name: '',
  description: '',
  content: '',
})

const editSkillForm = reactive({
  originalSkill: null,
  scope: 'workspace',
  name: '',
  description: '',
  content: '',
})

const scopeOptions = computed(() => [
  { value: 'workspace', label: t('Workspace scope') },
  { value: 'user', label: t('User scope') },
])

const skillGroups = computed(() => {
  const bundled = []
  const workspaceManaged = []
  const userManaged = []
  const external = []
  const query = String(searchQuery.value || '').trim().toLowerCase()

  for (const skill of filesystemSkills.value) {
    const haystack = [
      skill.name,
      skill.description,
      skill.sourceRootPath,
      ...(skill.supportingFiles || []),
    ].join(' ').toLowerCase()

    if (query && !haystack.includes(query)) {
      continue
    }

    if (skill.source === 'altals-workspace') {
      bundled.push(skill)
      continue
    }

    if (canDeleteSkill(skill)) {
      if (skill.scope === 'user') userManaged.push(skill)
      else workspaceManaged.push(skill)
      continue
    }

    external.push(skill)
  }

  return [
    { id: 'bundled', label: t('Bundled research pack'), skills: bundled },
    { id: 'workspace-managed', label: t('Workspace managed skills'), skills: workspaceManaged },
    { id: 'user-managed', label: t('User managed skills'), skills: userManaged },
    { id: 'external', label: t('External discovered skills'), skills: external },
  ].filter((group) => group.skills.length > 0)
})

function resetMessages() {
  pageError.value = ''
  pageSuccess.value = ''
}

async function loadPageState() {
  const [config, roots, nextWritableRoots] = await Promise.all([
    loadAiConfig(),
    resolveManagedSkillRoots({
      workspacePath: workspace.path || '',
      globalConfigDir: workspace.globalConfigDir || '',
    }),
    resolveWritableSkillRoots({
      workspacePath: workspace.path || '',
      globalConfigDir: workspace.globalConfigDir || '',
    }),
  ])
  enabledToolIds.value = new Set(config.enabledTools || [])
  managedRoots.value = roots
  writableRoots.value = nextWritableRoots
}

async function refreshSkills() {
  resetMessages()
  await aiStore.refreshFilesystemSkills()
  const [nextManagedRoots, nextWritableRoots] = await Promise.all([
    resolveManagedSkillRoots({
      workspacePath: workspace.path || '',
      globalConfigDir: workspace.globalConfigDir || '',
    }),
    resolveWritableSkillRoots({
      workspacePath: workspace.path || '',
      globalConfigDir: workspace.globalConfigDir || '',
    }),
  ])
  managedRoots.value = nextManagedRoots
  writableRoots.value = nextWritableRoots
}

async function persistToolState() {
  const config = await loadAiConfig()
  await saveAiConfig({
    ...config,
    enabledTools: [...enabledToolIds.value],
  })
  await aiStore.refreshProviderState()
}

async function toggleTool(toolId = '', nextValue = false) {
  resetMessages()
  const next = new Set(enabledToolIds.value)
  if (nextValue) next.add(toolId)
  else next.delete(toolId)
  enabledToolIds.value = next

  try {
    await persistToolState()
    pageSuccess.value = t('Tool registry updated.')
  } catch (error) {
    pageError.value = error instanceof Error ? error.message : t('Failed to update tool registry.')
  }
}

async function submitCreateSkill() {
  resetMessages()
  try {
    await createManagedSkill({
      workspacePath: workspace.path || '',
      globalConfigDir: workspace.globalConfigDir || '',
      scope: managementScope.value,
      name: createSkillForm.name,
      description: createSkillForm.description,
      body: createSkillForm.content,
    })
    createModalVisible.value = false
    createSkillForm.name = ''
    createSkillForm.description = ''
    createSkillForm.content = ''
    pageSuccess.value = t('Skill created.')
    await refreshSkills()
  } catch (error) {
    pageError.value = error instanceof Error ? error.message : t('Failed to create skill.')
  }
}

async function importSkillByMode(directory = false) {
  resetMessages()
  const selected = await open({
    multiple: false,
    directory,
    title: directory ? t('Import skill folder') : t('Import SKILL.md'),
    filters: directory ? undefined : [{ name: 'Markdown', extensions: ['md'] }],
  })

  if (!selected || Array.isArray(selected)) return

  try {
    await importManagedSkill({
      workspacePath: workspace.path || '',
      globalConfigDir: workspace.globalConfigDir || '',
      scope: managementScope.value,
      sourcePath: String(selected),
    })
    pageSuccess.value = t('Skill imported.')
    await refreshSkills()
  } catch (error) {
    pageError.value = error instanceof Error ? error.message : t('Failed to import skill.')
  }
}

async function importSkillFile() {
  await importSkillByMode(false)
}

async function importSkillDirectory() {
  await importSkillByMode(true)
}

async function installBundled(skill = {}) {
  resetMessages()
  try {
    await installBundledSkill({
      workspacePath: workspace.path || '',
      globalConfigDir: workspace.globalConfigDir || '',
      scope: managementScope.value,
      sourceDirectoryPath: skill.directoryPath,
    })
    pageSuccess.value = t('Skill installed.')
    await refreshSkills()
  } catch (error) {
    pageError.value = error instanceof Error ? error.message : t('Failed to install skill.')
  }
}

function canDeleteSkill(skill = {}) {
  return isManagedSkill(skill, managedRoots.value)
}

function canEditSkill(skill = {}) {
  return isWritableSkill(skill, writableRoots.value)
}

function canDuplicateSkill(skill = {}) {
  return isWritableSkill(skill, writableRoots.value)
}

function beginEditSkill(skill = {}) {
  resetMessages()
  editSkillForm.originalSkill = skill
  editSkillForm.scope = skill.scope || 'workspace'
  editSkillForm.name = skill.name || ''
  editSkillForm.description = skill.frontmatter?.description || ''
  editSkillForm.content = skill.body || ''
  editModalVisible.value = true
}

async function deleteSkill(skill = {}) {
  resetMessages()
  const confirmed = await ask(t('Delete this managed skill pack?'), {
    title: t('Delete'),
    kind: 'warning',
  })
  if (!confirmed) return

  try {
    await deleteManagedSkill({
      workspacePath: workspace.path || '',
      globalConfigDir: workspace.globalConfigDir || '',
      skill,
    })
    pageSuccess.value = t('Skill deleted.')
    await refreshSkills()
  } catch (error) {
    pageError.value = error instanceof Error ? error.message : t('Failed to delete skill.')
  }
}

async function submitEditSkill() {
  resetMessages()
  try {
    const updater = canDeleteSkill(editSkillForm.originalSkill)
      ? updateManagedSkill
      : updateWritableSkill

    await updater({
      workspacePath: workspace.path || '',
      globalConfigDir: workspace.globalConfigDir || '',
      skill: editSkillForm.originalSkill,
      nextName: editSkillForm.name,
      nextDescription: editSkillForm.description,
      nextBody: editSkillForm.content,
    })
    editModalVisible.value = false
    editSkillForm.originalSkill = null
    editSkillForm.name = ''
    editSkillForm.description = ''
    editSkillForm.content = ''
    pageSuccess.value = t('Skill updated.')
    await refreshSkills()
  } catch (error) {
    pageError.value = error instanceof Error ? error.message : t('Failed to update skill.')
  }
}

async function duplicateSkill(skill = {}) {
  resetMessages()
  try {
    await duplicateWritableSkill({
      workspacePath: workspace.path || '',
      globalConfigDir: workspace.globalConfigDir || '',
      skill,
    })
    pageSuccess.value = t('Skill duplicated.')
    await refreshSkills()
  } catch (error) {
    pageError.value = error instanceof Error ? error.message : t('Failed to duplicate skill.')
  }
}

async function exportSkill(skill = {}) {
  resetMessages()
  const selected = await open({
    multiple: false,
    directory: true,
    title: t('Export skill'),
  })
  if (!selected || Array.isArray(selected)) return

  try {
    await exportSkillDirectory({
      skill,
      destinationDirectory: String(selected),
    })
    pageSuccess.value = t('Skill exported.')
  } catch (error) {
    pageError.value = error instanceof Error ? error.message : t('Failed to export skill.')
  }
}

async function openSkillFile(skill = {}) {
  if (!skill?.skillFilePath) return
  workspace.closeSettings()
  editorStore.openFile(skill.skillFilePath)
}

async function revealSkillDirectory(skill = {}) {
  if (!skill?.directoryPath) return
  await revealPathInFileManager({ path: skill.directoryPath })
}

async function openSupportFile(skill = {}, relativePath = '') {
  const normalizedRelativePath = String(relativePath || '').trim()
  if (!skill?.directoryPath || !normalizedRelativePath) return
  workspace.closeSettings()
  editorStore.openFile(`${skill.directoryPath}/${normalizedRelativePath}`)
}

onMounted(async () => {
  await loadPageState()
  await aiStore.refreshFilesystemSkills()
})
</script>

<style scoped>
.settings-skills-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  flex-wrap: wrap;
}

.settings-skills-list {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.settings-skills-group-list {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.settings-skills-group {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.settings-skills-group__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.settings-skills-group__title {
  margin: 0;
  font-size: 13px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text-secondary);
}

.settings-skills-group__count {
  padding: 2px 8px;
  border-radius: 999px;
  background: color-mix(in srgb, var(--surface-base) 84%, transparent);
  color: var(--text-secondary);
  font-size: 11px;
}

.settings-skills-card {
  border: 1px solid color-mix(in srgb, var(--border) 55%, transparent);
  border-radius: 16px;
  padding: 16px;
  background: color-mix(in srgb, var(--surface-raised) 72%, transparent);
}

.settings-skills-card__header {
  display: flex;
  justify-content: space-between;
  gap: 16px;
}

.settings-skills-card__copy {
  min-width: 0;
  flex: 1 1 auto;
}

.settings-skills-card__titleline {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.settings-skills-card__title {
  margin: 0;
  font-size: 15px;
  font-weight: 600;
  color: var(--text-primary);
}

.settings-skills-card__badge {
  border-radius: 999px;
  padding: 3px 10px;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  background: color-mix(in srgb, var(--surface-base) 84%, transparent);
  color: var(--text-secondary);
}

.settings-skills-card__description {
  margin: 8px 0 0;
  font-size: 12.5px;
  line-height: 1.5;
  color: var(--text-muted);
}

.settings-skills-card__actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  align-items: flex-start;
}

.settings-skills-card__meta {
  margin-top: 12px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  font-size: 12px;
  line-height: 1.5;
  color: var(--text-secondary);
  word-break: break-word;
}

.settings-skills-card__support-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
}

@media (max-width: 860px) {
  .settings-skills-card__header {
    flex-direction: column;
  }
}
</style>
