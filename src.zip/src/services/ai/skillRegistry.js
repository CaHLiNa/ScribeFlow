import { isAiContextAvailable } from '../../domains/ai/aiContextRuntime.js'

export const AI_BUILT_IN_ACTION_DEFINITIONS = [
  {
    id: 'grounded-chat',
    kind: 'built-in-action',
    titleKey: 'Grounded chat',
    descriptionKey: 'Ask the AI about the active workbench context without leaving the project.',
    requiredContext: ['document'],
  },
]

export const AI_SKILL_DEFINITIONS = AI_BUILT_IN_ACTION_DEFINITIONS

const REQUIRED_CONTEXT_LABELS = {
  document: 'active document',
  selection: 'selected text',
  reference: 'selected reference',
}

function getDisplayTitle(entry = {}) {
  return String(entry.titleKey || entry.name || entry.id || '').trim()
}

function getDocumentBlock(contextBundle = {}) {
  if (!contextBundle.document?.available) return '- Active document: unavailable'
  return `- Active document: ${contextBundle.document.filePath}`
}

function getSelectionBlock(contextBundle = {}) {
  if (!contextBundle.selection?.available) return '- Selected text: unavailable'
  return [
    '- Selected text:',
    '```text',
    contextBundle.selection.text,
    '```',
  ].join('\n')
}

function getReferenceBlock(contextBundle = {}) {
  if (!contextBundle.reference?.available) return '- Selected reference: unavailable'

  const parts = [
    `- Selected reference title: ${contextBundle.reference.title || 'Untitled reference'}`,
  ]
  if (contextBundle.reference.citationKey) {
    parts.push(`- Citation key: ${contextBundle.reference.citationKey}`)
  }
  if (contextBundle.reference.year) {
    parts.push(`- Year: ${contextBundle.reference.year}`)
  }
  if (contextBundle.reference.authorLine) {
    parts.push(`- Author line: ${contextBundle.reference.authorLine}`)
  }
  return parts.join('\n')
}

function buildMissingContextBlock(entry = {}, contextBundle = {}) {
  const requiredContext = Array.isArray(entry.requiredContext) ? entry.requiredContext : []
  const missing = requiredContext.filter((kind) => !isAiContextAvailable(kind, contextBundle))
  if (missing.length === 0) return ''

  return [
    `Action: ${getDisplayTitle(entry)}`,
    '',
    'This action is not fully grounded yet.',
    'Missing context:',
    ...missing.map((kind) => `- ${REQUIRED_CONTEXT_LABELS[kind] || kind}`),
  ].join('\n')
}

const BUILT_IN_BRIEF_BUILDERS = {
  'grounded-chat': (contextBundle) =>
    [
      'Task: Answer the user in a grounded way using the currently active project context.',
      '',
      'Context:',
      getDocumentBlock(contextBundle),
      contextBundle.selection.available ? getSelectionBlock(contextBundle) : '- Selected text: unavailable',
      contextBundle.reference.available ? getReferenceBlock(contextBundle) : '- Selected reference: unavailable',
      '',
      'Requirements:',
      '- Stay close to the supplied project context.',
      '- Make uncertainty explicit instead of inventing support.',
      '- Keep the answer useful for a research workflow.',
    ].join('\n'),
}

export function getAiSkillBehaviorId(entry = null, fallbackSkillId = '') {
  if (!entry) return String(fallbackSkillId || '').trim()
  if (entry.kind === 'filesystem-skill') {
    return String(entry.slug || entry.name || fallbackSkillId || '').trim()
  }
  return String(entry.id || fallbackSkillId || '').trim()
}

function buildFilesystemSkillBrief(skill = {}, contextBundle = {}) {
  return [
    `Skill: ${skill.name || skill.slug || 'Unnamed skill'}`,
    `Type: filesystem skill`,
    `Source path: ${skill.skillFilePath || skill.directoryPath || 'unknown'}`,
    `Scope: ${skill.scope || 'workspace'}`,
    skill.supportingFiles?.length
      ? `Supporting files in skill directory: ${skill.supportingFiles.join(', ')}`
      : 'Supporting files in skill directory: none discovered',
    '',
    'Grounded project context:',
    getDocumentBlock(contextBundle),
    getSelectionBlock(contextBundle),
    getReferenceBlock(contextBundle),
    '',
    'Skill instructions (from SKILL.md):',
    '```md',
    String(skill.markdown || '').trim(),
    '```',
    '',
    'Requirements:',
    '- Follow the skill instructions as the primary workflow.',
    '- Stay grounded in the supplied Altals project context.',
    '- If the skill expects tools or files not yet available, say so explicitly instead of inventing them.',
  ].join('\n')
}

export function getBuiltInAiActionById(actionId = '') {
  return AI_BUILT_IN_ACTION_DEFINITIONS.find((action) => action.id === actionId) || null
}

export function getAiSkillById(skillId = '', filesystemSkills = []) {
  return (
    getBuiltInAiActionById(skillId)
    || (Array.isArray(filesystemSkills)
      ? filesystemSkills.find((skill) => skill.id === skillId) || null
      : null)
  )
}

export function buildPreparedAiBrief(skillOrId = '', contextBundle = {}, options = {}) {
  const filesystemSkills = Array.isArray(options.filesystemSkills) ? options.filesystemSkills : []
  const entry = typeof skillOrId === 'string'
    ? getAiSkillById(skillOrId, filesystemSkills)
    : skillOrId

  if (!entry) return ''

  if (entry.kind === 'filesystem-skill') {
    return buildFilesystemSkillBrief(entry, contextBundle)
  }

  const missingContextBlock = buildMissingContextBlock(entry, contextBundle)
  if (missingContextBlock) return missingContextBlock

  const builder = BUILT_IN_BRIEF_BUILDERS[entry.id]
  return typeof builder === 'function' ? builder(contextBundle) : ''
}
