import { extractJsonPayload, normalizeAiArtifact } from '../../domains/ai/aiArtifactRuntime.js'
import {
  buildPreparedAiBrief,
  getAiSkillBehaviorId,
  getAiSkillById,
} from './skillRegistry.js'
import { loadSkillSupportingFiles, buildSkillSupportPromptBlock } from './skillSupportFiles.js'
import {
  AI_TOOL_DEFINITIONS,
  buildAiToolPromptBlock,
  resolveEnabledAiTools,
} from './toolRegistry.js'
import { requestOpenAiCompatibleCompletion } from './openAiCompatible.js'

function buildSystemPrompt(skill = {}) {
  return [
    'You are Altals AI, a local-first academic research assistant embedded in a writing workbench.',
    'You must stay grounded in the supplied project context and never invent evidence or citations.',
    'Return valid JSON only.',
    `Current entry: ${skill.id || 'unknown'}.`,
  ].join(' ')
}

function buildResponseContract(skillId = '', contextBundle = {}) {
  if (skillId === 'grounded-chat') {
    return [
      'Return JSON with this shape:',
      '{',
      '  "answer": "grounded answer for the user",',
      '  "rationale": "brief note about what context supported the answer"',
      '}',
    ].join('\n')
  }

  if (skillId === 'revise-with-citations') {
    return [
      'Return JSON with this shape:',
      '{',
      '  "replacement_text": "the revised paragraph only",',
      '  "citation_suggestion": "where the citation should appear",',
      '  "rationale": "why this revision is grounded in the supplied context"',
      '}',
    ].join('\n')
  }

  if (skillId === 'draft-related-work') {
    return [
      'Return JSON with this shape:',
      '{',
      '  "paragraph": "related-work paragraph",',
      '  "citation_suggestion": "citation placement guidance",',
      '  "rationale": "how the paragraph uses the supplied reference",',
      '  "title": "optional short title for a note if no direct patch should be applied"',
      '}',
    ].join('\n')
  }

  if (skillId === 'summarize-selection') {
    return [
      'Return JSON with this shape:',
      '{',
      '  "title": "short note title",',
      '  "note_markdown": "# Heading\\n\\nstructured markdown note",',
      '  "takeaway": "one sentence takeaway",',
      '  "rationale": "why these are the key points"',
      '}',
    ].join('\n')
  }

  if (skillId === 'find-supporting-references') {
    return [
      'Return JSON with this shape:',
      '{',
      '  "answer": "diagnosis of what support is missing",',
      '  "rationale": "what in the passage created this diagnosis",',
      '  "title": "optional short label"',
      '}',
    ].join('\n')
  }

  return [
    'Return JSON with this shape:',
    '{',
    '  "answer": "useful grounded answer",',
    '  "rationale": "brief support note"',
    '}',
  ].join('\n')
}

function buildUserPrompt({
  skill = {},
  contextBundle = {},
  userInstruction = '',
  conversation = [],
  filesystemSkills = [],
  supportFiles = [],
} = {}) {
  const brief = buildPreparedAiBrief(skill, contextBundle, { filesystemSkills })
  const toolBlock = buildAiToolPromptBlock(resolveEnabledAiTools(skill.enabledToolIds || [], AI_TOOL_DEFINITIONS))
  const supportFileBlock = buildSkillSupportPromptBlock(supportFiles)
  const behaviorId = getAiSkillBehaviorId(skill)
  const historyBlock = conversation.length
    ? [
      'Recent conversation:',
      ...conversation.map((message) => `${message.role.toUpperCase()}: ${message.content}`),
      '',
    ].join('\n')
    : ''

  return [
    brief,
    '',
    toolBlock,
    '',
    supportFileBlock,
    '',
    historyBlock,
    userInstruction
      ? `Additional user instruction:\n${String(userInstruction || '').trim()}`
      : 'Additional user instruction:\nNone.',
    '',
    buildResponseContract(behaviorId, contextBundle),
  ].join('\n')
}

export async function executeAiSkill({
  skillId = '',
  skill = null,
  contextBundle = {},
  config = {},
  apiKey = '',
  userInstruction = '',
  conversation = [],
  filesystemSkills = [],
  signal,
} = {}) {
  const resolvedSkill = skill || getAiSkillById(skillId, filesystemSkills)
  if (!resolvedSkill) {
    throw new Error('AI skill is not available.')
  }

  const enabledToolIds = Array.isArray(config?.enabledTools) ? config.enabledTools : []
  const enabledToolSet = new Set(enabledToolIds)

  const supportFiles = resolvedSkill.kind === 'filesystem-skill'
    && enabledToolSet.has('load-skill-support-files')
    ? await loadSkillSupportingFiles(resolvedSkill)
    : []
  const behaviorId = getAiSkillBehaviorId(resolvedSkill, skillId)

  const messages = [
    {
      role: 'system',
      content: buildSystemPrompt(resolvedSkill),
    },
    {
      role: 'user',
      content: buildUserPrompt({
        skill: resolvedSkill,
        contextBundle,
        userInstruction,
        conversation,
        filesystemSkills,
        skill: { ...resolvedSkill, enabledToolIds },
        supportFiles,
      }),
    },
  ]

  const { content } = await requestOpenAiCompatibleCompletion(config, apiKey, messages, {
    signal,
  })

  const payload = extractJsonPayload(content) || {
    answer: content,
  }

  const artifact = normalizeAiArtifact(behaviorId, payload, contextBundle, content)
  return {
    skill: resolvedSkill,
    behaviorId,
    supportFiles,
    content,
    payload,
    artifact,
  }
}
