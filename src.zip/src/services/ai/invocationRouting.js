function normalizeInvocationName(value = '') {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/^[/$]+/, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

function getInvocationDraft(prompt = '') {
  const normalized = String(prompt || '')
  const match = normalized.match(/^\s*([/$])([^\s]*)/)
  if (!match) return null

  return {
    prefix: match[1],
    partialName: normalizeInvocationName(match[2]),
    rawToken: String(match[2] || ''),
    prompt: normalized,
  }
}

export function parseAiInvocationInput(input = '') {
  const normalized = String(input || '').trim()
  if (!normalized) return null

  const match = normalized.match(/^([/$])([^\s]+)(?:\s+([\s\S]*))?$/)
  if (!match) return null

  return {
    prefix: match[1],
    name: normalizeInvocationName(match[2]),
    rawName: String(match[2] || ''),
    remainder: String(match[3] || '').trim(),
  }
}

export function getAiInvocationSuggestions({
  prompt = '',
  builtInActions = [],
  filesystemSkills = [],
  recentSkillIds = [],
} = {}) {
  const draft = getInvocationDraft(prompt)
  if (!draft) return []
  const recentSet = new Set(
    (Array.isArray(recentSkillIds) ? recentSkillIds : [])
      .map((item) => String(item || '').trim())
      .filter(Boolean)
  )

  if (draft.prefix === '/') {
    return (Array.isArray(builtInActions) ? builtInActions : [])
      .filter((action) =>
        normalizeInvocationName(action.id).includes(draft.partialName)
      )
      .map((action) => ({
        id: action.id,
        kind: 'built-in-action',
        prefix: '/',
        groupKey: recentSet.has(action.id) ? 'recent-shell-actions' : 'shell-actions',
        groupLabel: recentSet.has(action.id) ? 'Recent shell actions' : 'Shell actions',
        insertText: `/${action.id} `,
        title: action.titleKey || action.id,
        description: action.descriptionKey || '',
      }))
  }

  if (draft.prefix === '$') {
    return (Array.isArray(filesystemSkills) ? filesystemSkills : [])
      .filter((skill) =>
        normalizeInvocationName(skill.slug || skill.name || skill.directoryName).includes(draft.partialName)
      )
      .map((skill) => ({
        id: skill.id,
        kind: 'filesystem-skill',
        prefix: '$',
        groupKey: recentSet.has(skill.id) ? 'recent-skills' : 'filesystem-skills',
        groupLabel: recentSet.has(skill.id) ? 'Recent skills' : 'Filesystem skills',
        insertText: `$${skill.slug || normalizeInvocationName(skill.name || skill.directoryName)} `,
        title: skill.name || skill.slug || skill.directoryName || skill.id,
        description: skill.description || '',
      }))
  }

  return []
}

export function applyAiInvocationSuggestion(prompt = '', suggestion = null) {
  const normalizedPrompt = String(prompt || '')
  if (!suggestion?.insertText) return normalizedPrompt

  const match = normalizedPrompt.match(/^(\s*)([/$][^\s]*)([\s\S]*)$/)
  if (!match) return String(suggestion.insertText || '')

  const leading = String(match[1] || '')
  const remainder = String(match[3] || '').replace(/^\s*/, '')
  return `${leading}${suggestion.insertText}${remainder}`.trimEnd()
}

function matchBuiltInAction(name = '', actions = []) {
  return (Array.isArray(actions) ? actions : []).find((action) =>
    normalizeInvocationName(action.id) === name
  ) || null
}

function matchFilesystemSkill(name = '', skills = []) {
  return (Array.isArray(skills) ? skills : []).find((skill) =>
    normalizeInvocationName(skill.slug || skill.name || skill.directoryName) === name
  ) || null
}

export function resolveAiInvocation({
  prompt = '',
  activeSkill = null,
  builtInActions = [],
  filesystemSkills = [],
} = {}) {
  const parsed = parseAiInvocationInput(prompt)
  if (!parsed) {
    return {
      resolvedSkill: activeSkill,
      userInstruction: String(prompt || '').trim(),
      invocation: null,
    }
  }

  if (parsed.prefix === '/') {
    const action = matchBuiltInAction(parsed.name, builtInActions)
    if (action) {
      return {
        resolvedSkill: action,
        userInstruction: parsed.remainder,
        invocation: parsed,
      }
    }
  }

  if (parsed.prefix === '$') {
    const skill = matchFilesystemSkill(parsed.name, filesystemSkills)
    if (skill) {
      return {
        resolvedSkill: skill,
        userInstruction: parsed.remainder,
        invocation: parsed,
      }
    }
  }

  return {
    resolvedSkill: activeSkill,
    userInstruction: String(prompt || '').trim(),
    invocation: null,
  }
}
